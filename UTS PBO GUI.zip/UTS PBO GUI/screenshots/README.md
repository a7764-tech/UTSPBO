# Screenshot aplikasi

Simpan screenshot hasil menjalankan aplikasi di folder ini dengan nama berikut:

- `01-dashboard.png`
- `02-produk.png`
- `03-transaksi.png`
- `04-struk.png`
- `05-riwayat.png`

Gunakan data demo sintetis bawaan, bukan transaksi nyata.
