package com.pos.ui;

import com.pos.security.*;
import javax.swing.*;
import java.awt.*;

public final class LoginDialog extends JDialog {
    private final AuthService auth=new AuthService();private final JTextField username=new JTextField();private final JPasswordField password=new JPasswordField();private UserSession session;
    public LoginDialog(Frame owner){super(owner,"Masuk ke POS Kasir",true);setDefaultCloseOperation(DISPOSE_ON_CLOSE);setSize(420,390);setResizable(false);setLocationRelativeTo(owner);build();}
    public UserSession showLogin(){setVisible(true);return session;}
    private void build(){JPanel root=new JPanel(new BorderLayout(0,18));root.setBackground(Ui.BG);root.setBorder(BorderFactory.createEmptyBorder(26,30,24,30));JPanel heading=new JPanel();heading.setOpaque(false);heading.setLayout(new BoxLayout(heading,BoxLayout.Y_AXIS));JLabel title=new JLabel("POS KASIR");title.setFont(new Font("Segoe UI",Font.BOLD,25));title.setForeground(Ui.NAVY);title.setAlignmentX(Component.LEFT_ALIGNMENT);JLabel sub=new JLabel("Silakan masuk untuk melanjutkan");sub.setFont(Ui.BODY);sub.setForeground(Ui.MUTED);sub.setAlignmentX(Component.LEFT_ALIGNMENT);heading.add(title);heading.add(Box.createVerticalStrut(5));heading.add(sub);root.add(heading,BorderLayout.NORTH);
        JPanel form=Ui.card();form.setLayout(new BoxLayout(form,BoxLayout.Y_AXIS));field(form,"Username",username);field(form,"Password",password);JButton login=Ui.button("Masuk");login.setBackground(new Color(218,232,250));login.setAlignmentX(Component.LEFT_ALIGNMENT);login.setMaximumSize(new Dimension(Integer.MAX_VALUE,38));form.add(Box.createVerticalStrut(4));form.add(login);login.addActionListener(e->masuk());password.addActionListener(e->masuk());root.add(form,BorderLayout.CENTER);
        JLabel hint=new JLabel("Demo: admin / admin123   •   kasir / kasir123");hint.setFont(new Font("Segoe UI",Font.PLAIN,11));hint.setForeground(Ui.MUTED);root.add(hint,BorderLayout.SOUTH);setContentPane(root);getRootPane().setDefaultButton(login);}
    private void field(JPanel parent,String label,JTextField input){JLabel l=Ui.label(label);l.setAlignmentX(Component.LEFT_ALIGNMENT);input.setFont(Ui.BODY);input.setMaximumSize(new Dimension(Integer.MAX_VALUE,34));parent.add(l);parent.add(Box.createVerticalStrut(5));parent.add(input);parent.add(Box.createVerticalStrut(13));}
    private void masuk(){char[] pass=password.getPassword();try{session=auth.authenticate(username.getText(),pass).orElse(null);if(session==null){password.setText("");JOptionPane.showMessageDialog(this,"Username atau password tidak sesuai.","Login gagal",JOptionPane.WARNING_MESSAGE);password.requestFocusInWindow();return;}dispose();}finally{java.util.Arrays.fill(pass,'\0');}}
}
