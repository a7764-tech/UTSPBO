package com.pos.service;
import com.pos.model.Produk;import com.pos.repository.ProdukRepository;import java.util.*;
public class ProdukService {private final ProdukRepository repo;public ProdukService(ProdukRepository repo){this.repo=repo;}
 public List<Produk> semua(){return repo.cariSemua(false);}public List<Produk> semua(boolean termasukArsip){return repo.cariSemua(termasukArsip);}public List<Produk> cari(String q){return repo.cari(q);}public long hitung(){return repo.hitung();}
 public void tambah(String kode,String nama,long harga,int stok){if(kode==null||kode.isBlank())throw new IllegalArgumentException("Kode produk wajib diisi.");if(repo.cariByKode(kode).isPresent())throw new IllegalArgumentException("Kode produk sudah digunakan.");repo.simpan(new Produk(0,kode,nama,harga,stok,true));}
 public void ubah(long id,String nama,long harga,int stok,boolean aktif){Produk p=repo.cariById(id).orElseThrow(()->new IllegalArgumentException("Produk tidak ditemukan."));p.ubahData(nama,harga,stok,aktif);repo.update(p);}
 public void hapus(long id){repo.hapus(id);}
}
