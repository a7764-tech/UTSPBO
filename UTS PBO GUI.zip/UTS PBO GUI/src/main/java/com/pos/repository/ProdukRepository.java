package com.pos.repository;
import com.pos.model.Produk;import java.util.*;
/** Abstraction for product persistence; alternative implementations can be substituted polymorphically. */
public interface ProdukRepository {
 List<Produk> cariSemua(boolean termasukNonaktif); Optional<Produk> cariById(long id); Optional<Produk> cariByKode(String kode);
 List<Produk> cari(String kataKunci); void simpan(Produk produk); void update(Produk produk); void hapus(long id);
 long hitung();
}
