package com.pos.repository;
import com.pos.model.*;import java.util.*;
public interface TransaksiRepository {
 void simpanTransaksi(Transaksi transaksi); List<RingkasanTransaksi> cariRiwayat(String filter); Optional<Transaksi> cariDetail(String nomor); long hitung();
 record RingkasanTransaksi(String nomor,String waktu,long total,long bayar,long kembalian,String metodePembayaran){}
}
