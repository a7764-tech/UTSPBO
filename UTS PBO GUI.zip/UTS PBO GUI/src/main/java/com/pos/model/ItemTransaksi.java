package com.pos.model;

/** Snapshot of a product at the time of sale. */
public class ItemTransaksi {
    private final long produkId; private final String kodeProduk, namaProduk; private final long hargaSatuan; private int kuantitas;
    public ItemTransaksi(long produkId,String kodeProduk,String namaProduk,long hargaSatuan,int kuantitas){
        if(namaProduk==null||namaProduk.isBlank())throw new IllegalArgumentException("Nama produk wajib diisi.");
        if(hargaSatuan<0)throw new IllegalArgumentException("Harga tidak boleh negatif.");
        if(kuantitas<=0)throw new IllegalArgumentException("Kuantitas harus lebih dari nol.");
        this.produkId=produkId;this.kodeProduk=kodeProduk;this.namaProduk=namaProduk;this.hargaSatuan=hargaSatuan;this.kuantitas=kuantitas;
    }
    public long getProdukId(){return produkId;} public String getKodeProduk(){return kodeProduk;} public String getNamaProduk(){return namaProduk;}
    public long getHargaSatuan(){return hargaSatuan;} public int getKuantitas(){return kuantitas;}
    public long getSubtotal(){return Math.multiplyExact(hargaSatuan,kuantitas);}
    public void setKuantitas(int nilai){if(nilai<=0)throw new IllegalArgumentException("Kuantitas harus lebih dari nol.");kuantitas=nilai;}
}
