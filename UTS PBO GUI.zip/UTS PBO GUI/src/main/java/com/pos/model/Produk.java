package com.pos.model;

/** Domain object for a product; all state is private and changed through validated methods. */
public class Produk {
    private final long id;
    private final String kode;
    private String nama;
    private long harga;
    private int stok;
    private boolean aktif;

    public Produk(long id, String kode, String nama, long harga, int stok, boolean aktif) {
        if (kode == null || kode.isBlank()) throw new IllegalArgumentException("Kode produk wajib diisi.");
        validasiNama(nama); validasiHarga(harga); validasiStok(stok);
        this.id=id; this.kode=kode.trim(); this.nama=nama.trim(); this.harga=harga; this.stok=stok; this.aktif=aktif;
    }
    public long getId(){return id;} public String getKode(){return kode;} public String getNama(){return nama;}
    public long getHarga(){return harga;} public int getStok(){return stok;} public boolean isAktif(){return aktif;}
    public void ubahData(String nama,long harga,int stok,boolean aktif){validasiNama(nama);validasiHarga(harga);validasiStok(stok);this.nama=nama.trim();this.harga=harga;this.stok=stok;this.aktif=aktif;}
    public void kurangiStok(int jumlah){if(jumlah<=0)throw new IllegalArgumentException("Kuantitas harus positif.");if(jumlah>stok)throw new IllegalStateException("Stok tidak mencukupi. Stok tersedia: "+stok);stok-=jumlah;}
    private static void validasiNama(String v){if(v==null||v.isBlank())throw new IllegalArgumentException("Nama produk wajib diisi.");}
    private static void validasiHarga(long v){if(v<0)throw new IllegalArgumentException("Harga tidak boleh negatif.");}
    private static void validasiStok(int v){if(v<0)throw new IllegalArgumentException("Stok tidak boleh negatif.");}
}
