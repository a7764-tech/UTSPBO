package com.pos.model;

import java.time.LocalDateTime;import java.util.*;
/** A sale composed of immutable-at-checkout line snapshots. */
public class Transaksi {
    private final String nomor; private final LocalDateTime waktu; private final List<ItemTransaksi> items=new ArrayList<>();
    private long bayar; private MetodePembayaran metodePembayaran=MetodePembayaran.CASH;
    public Transaksi(String nomor,LocalDateTime waktu){this.nomor=Objects.requireNonNull(nomor);this.waktu=Objects.requireNonNull(waktu);}
    public String getNomor(){return nomor;} public LocalDateTime getWaktu(){return waktu;} public List<ItemTransaksi> getItems(){return Collections.unmodifiableList(items);}
    public void tambahItem(ItemTransaksi item){items.add(Objects.requireNonNull(item));}
    public void hapusItem(int index){items.remove(index);}
    public long getTotal(){long total=0;for(ItemTransaksi i:items)total=Math.addExact(total,i.getSubtotal());return total;}
    public long getBayar(){return bayar;} public long getKembalian(){return Math.subtractExact(bayar,getTotal());} public MetodePembayaran getMetodePembayaran(){return metodePembayaran;}
    public void validasiPembayaran(long nominal){validasiPembayaran(nominal,MetodePembayaran.CASH);}
    public void validasiPembayaran(long nominal,MetodePembayaran metode){if(items.isEmpty())throw new IllegalStateException("Keranjang masih kosong.");Objects.requireNonNull(metode);if(nominal<getTotal())throw new IllegalArgumentException("Pembayaran kurang. Total yang harus dibayar: Rp "+getTotal());if(metode==MetodePembayaran.QRIS&&nominal!=getTotal())throw new IllegalArgumentException("Nominal pembayaran QRIS harus sama dengan total transaksi.");bayar=nominal;metodePembayaran=metode;}
}
