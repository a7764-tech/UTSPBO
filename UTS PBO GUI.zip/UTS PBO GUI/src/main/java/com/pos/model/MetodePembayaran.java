package com.pos.model;

public enum MetodePembayaran {
    CASH("Cash"), QRIS("QRIS (Simulasi)");
    private final String label;
    MetodePembayaran(String label){this.label=label;}
    @Override public String toString(){return label;}
}
