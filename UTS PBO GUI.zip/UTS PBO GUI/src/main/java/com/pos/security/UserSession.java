package com.pos.security;

public record UserSession(String username, String role) {}
