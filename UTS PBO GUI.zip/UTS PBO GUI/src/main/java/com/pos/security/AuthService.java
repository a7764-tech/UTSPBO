package com.pos.security;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.MessageDigest;
import java.util.*;

/** Local demo authentication. Passwords are stored as PBKDF2 hashes, not plain text. */
public final class AuthService {
    private static final byte[] SALT=HexFormat.of().parseHex("c4a17f6d2e9b4037a10d82ef56c3719a");
    private static final int ITERATIONS=120_000;
    private static final Map<String,Account> ACCOUNTS=Map.of(
        "admin",new Account("Administrator","d310ea9a7f8322d70b971f0f82c1c4189b7b467c604a110e46b886c7a0d64ea8"),
        "kasir",new Account("Kasir","31468429d5fb01310ade96ac19cfd10070474f82cd7c6d648ad956e64606d8c0")
    );
    public Optional<UserSession> authenticate(String username,char[] password){
        if(username==null||password==null)return Optional.empty();Account account=ACCOUNTS.get(username.trim().toLowerCase(Locale.ROOT));
        if(account==null)return Optional.empty();byte[] actual=hash(password);byte[] expected=HexFormat.of().parseHex(account.hash());
        return MessageDigest.isEqual(actual,expected)?Optional.of(new UserSession(username.trim(),account.role())):Optional.empty();
    }
    private byte[] hash(char[] password){PBEKeySpec spec=new PBEKeySpec(password,SALT,ITERATIONS,256);try{return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();}catch(Exception e){throw new IllegalStateException("Validasi login tidak dapat dijalankan.",e);}finally{spec.clearPassword();}}
    private record Account(String role,String hash){}
}
