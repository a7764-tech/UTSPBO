package com.pos.model;
import org.junit.jupiter.api.Test;import static org.junit.jupiter.api.Assertions.*;
class ProdukTest {
 @Test void rejectsBlankNameAndNegativeValues(){assertThrows(IllegalArgumentException.class,()->new Produk(0,"A"," ",100,1,true));assertThrows(IllegalArgumentException.class,()->new Produk(0,"A","Apel",-1,1,true));assertThrows(IllegalArgumentException.class,()->new Produk(0,"A","Apel",100,-1,true));}
 @Test void stockCannotBecomeNegative(){Produk p=new Produk(1,"A","Apel",100,2,true);p.kurangiStok(2);assertEquals(0,p.getStok());assertThrows(IllegalStateException.class,()->p.kurangiStok(1));}
}
