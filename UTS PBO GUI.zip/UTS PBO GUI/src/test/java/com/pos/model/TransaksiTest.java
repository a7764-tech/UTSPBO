package com.pos.model;
import org.junit.jupiter.api.Test;import java.time.LocalDateTime;import static org.junit.jupiter.api.Assertions.*;
class TransaksiTest {
 @Test void calculatesSubtotalTotalAndChange(){Transaksi t=new Transaksi("TRX-1",LocalDateTime.now());t.tambahItem(new ItemTransaksi(1,"A","Apel",2500,2));t.tambahItem(new ItemTransaksi(2,"B","Roti",4000,1));assertEquals(9000,t.getTotal());assertThrows(IllegalArgumentException.class,()->t.validasiPembayaran(8999));t.validasiPembayaran(10000);assertEquals(1000,t.getKembalian());}
 @Test void emptyCartCannotBePaid(){Transaksi t=new Transaksi("TRX-2",LocalDateTime.now());assertThrows(IllegalStateException.class,()->t.validasiPembayaran(100));}
 @Test void qrisMustMatchExactTotal(){Transaksi t=new Transaksi("TRX-3",LocalDateTime.now());t.tambahItem(new ItemTransaksi(1,"A","Apel",2500,2));assertThrows(IllegalArgumentException.class,()->t.validasiPembayaran(6000,MetodePembayaran.QRIS));t.validasiPembayaran(5000,MetodePembayaran.QRIS);assertEquals(MetodePembayaran.QRIS,t.getMetodePembayaran());assertEquals(0,t.getKembalian());}
}
