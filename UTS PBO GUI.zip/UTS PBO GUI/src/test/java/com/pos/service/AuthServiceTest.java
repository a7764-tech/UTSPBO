package com.pos.service;
import com.pos.security.AuthService;import org.junit.jupiter.api.Test;import static org.junit.jupiter.api.Assertions.*;
class AuthServiceTest {
 @Test void acceptsDemoAccountsAndRejectsInvalidPassword(){AuthService auth=new AuthService();assertEquals("Administrator",auth.authenticate("admin","admin123".toCharArray()).orElseThrow().role());assertEquals("Kasir",auth.authenticate("KASIR","kasir123".toCharArray()).orElseThrow().role());assertTrue(auth.authenticate("admin","salah".toCharArray()).isEmpty());}
}
