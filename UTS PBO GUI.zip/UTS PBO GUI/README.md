# POS Kasir UTS PBO

Aplikasi kasir desktop untuk simulasi penjualan toko kecil. Aplikasi menggunakan Java Swing, SQLite, dan arsitektur berlapis agar aturan bisnis, penyimpanan, dan tampilan memiliki tanggung jawab yang terpisah.

## Fitur

- Dashboard dengan jumlah produk aktif dan transaksi.
- CRUD produk, validasi kode unik, pencarian nama/kode, serta pengarsipan produk agar riwayat lama tetap aman.
- Pencarian produk dan keranjang yang mendukung tambah, ubah kuantitas, dan hapus item.
- Perhitungan subtotal, total, pembayaran tunai, dan kembalian menggunakan bilangan bulat Rupiah.
- Validasi stok ketika item masuk keranjang dan pemeriksaan ulang ketika transaksi disimpan.
- Penyimpanan transaksi, detail item, dan pengurangan stok secara atomik dengan commit/rollback SQLite.
- Struk transaksi yang tampil setelah pembayaran dan dapat diekspor ke file teks.
- Riwayat yang dapat dicari berdasarkan nomor transaksi/waktu, termasuk detail dan snapshot nama/harga saat penjualan.
- Database otomatis dibuat di `database/pos-kasir.db` saat aplikasi pertama dijalankan.
- Lima produk demo sintetis otomatis dimasukkan saat database produk masih kosong.
- Login lokal sebelum POS dibuka; akun demo `admin / admin123` dan `kasir / kasir123`.
- Pembayaran Cash dan QRIS simulasi; transaksi menyimpan metode pembayaran di struk dan riwayat.
- QRIS menghasilkan gambar QR dinamis yang memuat referensi dan nominal simulasi. QR ini **bukan QRIS merchant dan tidak memindahkan dana**.

## Prasyarat

- JDK 17 atau lebih baru (dikembangkan dengan Java 21).
- Maven 3.9 atau lebih baru untuk mengambil SQLite JDBC, ZXing QR Code, dan membangun aplikasi.
- Windows, Linux, atau macOS dengan dukungan Java Swing.

## Menjalankan aplikasi

Jalankan dari direktori proyek:

```bash
mvn clean compile exec:java
```

> Pada Windows, perintah yang sama dapat dijalankan melalui PowerShell atau terminal IDE setelah Maven ditambahkan ke PATH. Maven mengunduh driver SQLite JDBC dari repositori Maven Central pada build pertama.

Untuk membangun paket aplikasi:

```bash
mvn clean package
```

Jalankan pengujian otomatis model dan integrasi SQLite dengan `mvn test`.

Database lokal dibuat otomatis di folder `database`. File database diabaikan Git karena dapat berisi data transaksi lokal. Untuk reset demo, tutup aplikasi lalu hapus file tersebut.

## Struktur proyek

```text
src/main/java/com/pos/
├── Main.java
├── model/                 # Produk, ItemTransaksi, Transaksi
├── repository/            # Kontrak repository dan implementasi SQLite
├── service/               # Validasi dan alur bisnis
└── ui/                    # MainFrame, dashboard, produk, transaksi, riwayat
database/                  # Database lokal otomatis, tidak di-commit
screenshots/               # Dokumentasi visual aplikasi
pom.xml
```

## Struktur class dan penerapan PBO

- **Class dan object:** `Produk`, `ItemTransaksi`, dan `Transaksi` menjadi model domain yang dibuat dan digunakan pada saat aplikasi berjalan.
- **Encapsulation:** atribut model bersifat `private`. Perubahan dilakukan melalui constructor dan method tervalidasi, misalnya `Produk.ubahData()` dan `Produk.kurangiStok()`.
- **Abstraction:** `ProdukRepository` dan `TransaksiRepository` mendefinisikan kontrak penyimpanan. `KasirService` menggunakan kontrak tersebut tanpa mengetahui query SQL.
- **Polymorphism:** `SQLiteProdukRepository` mengimplementasikan `ProdukRepository` dan dapat dipertukarkan dengan implementasi lain tanpa mengubah `ProdukService`/`KasirService`.
- **Composition:** `Transaksi` memiliki kumpulan `ItemTransaksi`. Setiap item menyimpan snapshot kode, nama, harga, dan kuantitas pada saat penjualan.
- **Inheritance:** tidak dipaksakan karena versi UTS tidak memiliki relasi *is-a* antar entitas domain yang dibutuhkan. Swing sendiri memakai pewarisan komponen (`JFrame`, `JPanel`) untuk tampilan.

## Aturan bisnis utama

- Kode wajib unik; nama tidak boleh kosong; harga dan stok tidak boleh negatif.
- Kuantitas wajib positif dan tidak boleh melebihi stok tersedia.
- Pembayaran harus mencukupi; kembalian adalah pembayaran dikurangi total.
- Stok dikurangi hanya saat transaksi berhasil disimpan.
- Penghapusan produk berarti pengarsipan (`aktif = 0`), bukan penghapusan fisik, supaya detail transaksi tetap utuh.
- Semua nilai uang adalah `long` dalam satuan Rupiah; tidak memakai floating-point.
- Akun login demo menggunakan hash PBKDF2. Login ini untuk simulasi UTS, bukan autentikasi produksi.

## Login dan pembayaran

Masuk dengan salah satu akun demo yang ditampilkan pada layar login. Role ditampilkan pada header aplikasi; versi ini belum membatasi fitur berdasarkan role.

Pilih **Cash** untuk memasukkan nominal uang dan menghitung kembalian. Pilih **QRIS (Simulasi)** untuk membuat QR unik berisi referensi transaksi dan jumlah Rupiah, kemudian konfirmasi pembayaran simulasi. Karena belum ada payload merchant atau penyedia pembayaran, QR tersebut hanya membawa teks lokal POS dan tidak dapat dipindai sebagai pembayaran QRIS sungguhan. Untuk mengaktifkan pembayaran nyata diperlukan QRIS merchant resmi dan integrasi/konfirmasi dari penyedia pembayaran.

## Database

SQLite menggunakan tiga tabel: `produk`, `transaksi`, dan `detail_transaksi`. Foreign key diaktifkan pada setiap koneksi. Proses checkout membungkus pemeriksaan/pengurangan stok, penyimpanan header transaksi, dan penyimpanan seluruh detail dalam satu transaksi database. Kegagalan satu langkah menjalankan rollback.

## Alur demo UTS (3–5 menit)

1. Masuk dengan akun demo **admin** atau **kasir**.
2. Buka tab **Produk**, tambahkan produk, ubah stok/harga, dan tunjukkan penolakan kode duplikat.
3. Buka tab **Transaksi**, cari dua produk, tambahkan ke keranjang, dan ubah kuantitas.
4. Masukkan pembayaran Cash yang kurang lalu yang lebih untuk menunjukkan validasi dan kembalian.
5. Ulangi dengan **QRIS (Simulasi)**, tampilkan QR, lalu pilih konfirmasi simulasi.
6. Tampilkan struk dan buka **Riwayat** untuk memeriksa metode pembayaran dan detail transaksi.
7. Tutup dan buka ulang aplikasi untuk membuktikan database tetap menyimpan data.
8. Tunjukkan `Produk` (encapsulation), `Transaksi` dengan kumpulan item (composition), dan interface repository (abstraction/polymorphism).

## Skenario penerimaan

| ID | Skenario | Hasil yang diharapkan |
|---|---|---|
| TC-01 | Tambah produk valid | Produk muncul di tabel |
| TC-02 | Kode produk duplikat | Penyimpanan ditolak dengan pesan jelas |
| TC-03 | Ubah harga/stok | Perubahan bertahan setelah aplikasi dibuka ulang |
| TC-04–05 | Tambah/ubah kuantitas keranjang | Subtotal dan total dihitung ulang |
| TC-06 | Kuantitas lebih dari stok | Ditolak dengan informasi stok |
| TC-07 | Pembayaran kurang | Checkout ditolak; transaksi tidak tersimpan |
| TC-08–09 | Pembayaran tepat/lebih | Checkout sukses; kembalian benar |
| TC-10 | Checkout sukses | Header, detail, dan pengurangan stok konsisten |
| TC-11 | Buka ulang aplikasi | Produk dan riwayat tetap tersedia |
| TC-12 | Keranjang kosong | Checkout ditolak |
| TC-13 | Database gagal/terkunci | Pesan kesalahan; transaksi parsial tidak tertinggal |
| TC-14 | Buka struk lama setelah produk berubah | Snapshot nama/harga lama tetap ditampilkan |
| TC-15 | Jalankan sesuai README | Aplikasi dapat dijalankan dengan prasyarat di atas |

## Screenshot

Setelah aplikasi berjalan, simpan gambar beranda, data produk, transaksi/keranjang, struk pembayaran, dan riwayat ke folder `screenshots/`. Gambar tersebut menunjukkan tampilan dari aplikasi yang berjalan; data demo bawaan bersifat sintetis.

## Catatan repositori

Data demo sebaiknya berupa data sintetis. Jangan menambahkan transaksi nyata, file database lokal, kredensial, atau output build ke repository publik. Buat commit bertahap, jalankan skenario penerimaan, ambil screenshot dashboard/produk/transaksi/struk/riwayat, lalu pastikan repository dan tautannya sesuai instruksi dosen.
